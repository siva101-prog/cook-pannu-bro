import { motion, AnimatePresence } from "motion/react";
import { useState, useEffect, FormEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { Send, Bot, User, CheckCircle2, DollarSign, Clock, Mic, MicOff, Volume2, VolumeX, Check, AlertCircle, RefreshCcw, X, Image as ImageIcon, Play, Video, ChevronRight } from "lucide-react";
import { getBroAdvice, getBroSpeech, getRecipeImage, generateRecipeVideo, checkVideoOperation, getRelatedRecipes, BroAdvice, RelatedRecipe } from "../services/geminiService";

const SoundWave = () => (
  <div className="flex items-center gap-[2px] h-3 px-1">
    {[1, 2, 3, 4].map(i => (
      <motion.div
        key={i}
        animate={{ height: [2, 10, 2] }}
        transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
        className="w-[2px] bg-electric-lime rounded-full"
      />
    ))}
  </div>
);

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function CookPage() {
  const [searchParams] = useSearchParams();
  const initialIngredients = searchParams.get("ingredients") || "";
  
  const [messages, setMessages] = useState<{role: 'bro' | 'user', content: string}[]>([]);
  const [input, setInput] = useState("");
  const [currentRecipe, setCurrentRecipe] = useState<BroAdvice | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [recipeImageUrl, setRecipeImageUrl] = useState<string | null>(null);
  const [recipeGifUrl, setRecipeGifUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [relatedRecipes, setRelatedRecipes] = useState<RelatedRecipe[]>([]);
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [isFetchingRelated, setIsFetchingRelated] = useState(false);
  const [videoOperation, setVideoOperation] = useState<any | null>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [isFetchingGif, setIsFetchingGif] = useState(false);
  const [voiceError, setVoiceError] = useState<{text: string, id: string} | null>(null);
  const [checkedIngredients, setCheckedIngredients] = useState<Set<number>>(new Set());
  const chatContainerRef = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    // Reset checklist, video, and related when recipe changes
    setCheckedIngredients(new Set());
    setVideoUrl(null);
    setVideoOperation(null);
    setRelatedRecipes([]);
    setIsVideoLoading(false);
  }, [currentRecipe]);

  useEffect(() => {
    if (!videoOperation || videoUrl) return;

    const interval = setInterval(async () => {
      try {
        const opResult = await checkVideoOperation(videoOperation);
        if (opResult.done) {
          const vUrl = opResult.response?.generatedVideos?.[0]?.video?.uri;
          if (vUrl) {
            setVideoUrl(vUrl);
            setVideoOperation(null);
            setIsVideoLoading(false);
            clearInterval(interval);
          }
        } else {
          setVideoOperation(opResult);
        }
      } catch (error) {
        console.error("Video polling error:", error);
        clearInterval(interval);
        setIsVideoLoading(false);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [videoOperation, videoUrl]);

  useEffect(() => {
    // Auto-TTS on new Bro messages
    if (messages.length > 0 && messages[messages.length - 1].role === 'bro') {
      const lastMsg = messages[messages.length - 1].content;
      handleSpeak(lastMsg);
    }
  }, [messages]);

  useEffect(() => {
    // Scroll to bottom on new messages
    const chatEl = document.getElementById('chat-messages');
    if (chatEl) {
      chatEl.scrollTo({ top: chatEl.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialIngredients) {
      handleBroAdvice(initialIngredients);
    } else {
      setMessages([{ role: 'bro', content: "Maca! Tell me what's in your pantry and I'll drop a killer recipe scene. Don't be shy, Bro!" }]);
    }
  }, []);

  const handleBroAdvice = async (ingredientsStr: string) => {
    setMessages(prev => [...prev, { role: 'user', content: `Suggest something with: ${ingredientsStr}` }]);
    setIsLoading(true);
    setIsGeneratingImage(true);
    setRecipeImageUrl(null);
    
    const advice = await getBroAdvice(ingredientsStr.split(","));
    setCurrentRecipe(advice);
    
    // Fetch image in background
    getRecipeImage(advice.recipeName).then(url => {
      setRecipeImageUrl(url);
      setIsGeneratingImage(false);
    }).catch(() => {
      setIsGeneratingImage(false);
    });

    // Fetch dynamic GIF
    setIsFetchingGif(true);
    fetch(`https://api.giphy.com/v1/gifs/search?api_key=dc6zaTOxFJmzC&q=${encodeURIComponent(advice.recipeName + " cooking")}&limit=1`)
      .then(res => res.json())
      .then(data => {
        const url = data.data?.[0]?.images?.original?.url;
        setRecipeGifUrl(url || null);
        setIsFetchingGif(false);
      })
      .catch(() => setIsFetchingGif(false));

    // Fetch related recipes
    setIsFetchingRelated(true);
    getRelatedRecipes(ingredientsStr.split(",")).then(recipes => {
      setRelatedRecipes(recipes);
      setIsFetchingRelated(false);
    }).catch(() => setIsFetchingRelated(false));
    
    setMessages(prev => [...prev, { role: 'bro', content: `Check the recipe, Bro! ${advice.broTip}` }]);
    setIsLoading(false);
  };

  const handleSend = (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    handleBroAdvice(input);
    setInput("");
  };

  const handleStartVideo = async () => {
    if (!currentRecipe || isVideoLoading) return;

    // Veo requires a paid API key from the user
    if (typeof (window as any).aistudio !== 'undefined') {
      try {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio.openSelectKey();
          // Skill says assume success after openSelectKey()
        }
      } catch (e) {
        console.warn("API key selection failed or not supported in this context", e);
      }
    }

    setIsVideoLoading(true);
    setVideoUrl(null);
    try {
      const operation = await generateRecipeVideo(currentRecipe.recipeName, currentRecipe.steps, recipeImageUrl);
      setVideoOperation(operation);
    } catch (error: any) {
      console.error("Fail to start video:", error);
      setIsVideoLoading(false);
      
      // Handle the 403 Permission Denied precisely
      if (error?.message?.includes("permission") || error?.status === "PERMISSION_DENIED") {
        setVoiceError({
          text: "Bro, Veo needs a PAID API Key! Switch to a project with billing enabled in your settings.",
          id: "veo-permission"
        });
        // Prompt them again to select a key
        if (typeof (window as any).aistudio !== 'undefined') {
          await (window as any).aistudio.openSelectKey();
        }
      } else {
        setVoiceError({
          text: "Video Scene Failed, Bro! Maybe try again later?",
          id: "veo-fail"
        });
      }
    }
  };

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Bro, your browser doesn't support speech recognition scene. Try Chrome!");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error("Bro, mic error:", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const toggleIngredient = (index: number) => {
    const newChecked = new Set(checkedIngredients);
    if (newChecked.has(index)) {
      newChecked.delete(index);
    } else {
      newChecked.add(index);
    }
    setCheckedIngredients(newChecked);
  };

  const handleSpeak = (text: string) => {
    if (isMuted) return;
    window.speechSynthesis.cancel();
    
    // 1. Persona Preservation: Inject pauses after Bro/Da/Maca using punctuation
    const processedText = text.replace(/(Bro|Da|Maca)([ \t,.!?]|$)/gi, "$1. . . $2");

    const utterance = new SpeechSynthesisUtterance(processedText);
    
    // 2. Voice Settings: Male profile, 1.1x rate
    const voices = window.speechSynthesis.getVoices();
    // Try to find a male-sounding voice if possible
    const preferredVoice = voices.find(v => 
      (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('guy') || v.name.toLowerCase().includes('puck')) 
      && v.lang.startsWith('en')
    );
    
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.rate = 1.1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const playAudio = async (base64Audio: string) => {
    // Not strictly needed now that we use Web Speech synthesis, but kept as utility
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    try {
      const arrayBuffer = Uint8Array.from(atob(base64Audio), c => c.charCodeAt(0)).buffer;
      
      // Try to decode as encoded audio first (Vite/Browser might support it if it's a standard format)
      // Otherwise, fallback to raw PCM.
      // Clone the buffer because decodeAudioData detaches it
      const bufferForDecoding = arrayBuffer.slice(0);
      
      try {
        const audioBuffer = await audioContext.decodeAudioData(bufferForDecoding);
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.start();
        return new Promise((resolve) => {
          source.onended = resolve;
        });
      } catch (e) {
        // Fallback to raw PCM 16-bit 24kHz
        const dataView = new DataView(arrayBuffer);
        const pcmData = new Float32Array(arrayBuffer.byteLength / 2);
        for (let i = 0; i < pcmData.length; i++) {
          pcmData[i] = dataView.getInt16(i * 2, true) / 32768.0;
        }
        
        const audioBuffer = audioContext.createBuffer(1, pcmData.length, 24000);
        audioBuffer.getChannelData(0).set(pcmData);
        
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.start();
        return new Promise((resolve) => {
          source.onended = resolve;
        });
      }
    } catch (error) {
      console.error("Bro, audio playback failed:", error);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-white overflow-hidden bg-pattern">
      {/* Bro-Bot Sidebar Chat */}
      <aside className="w-[400px] border-r border-white/5 flex flex-col glass backdrop-blur-2xl">
        <div className="p-8 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 bg-electric-lime rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(204,255,0,0.2)]">
                <Bot className="text-black w-6 h-6" />
              </div>
              {isSpeaking && (
                <div className="absolute -bottom-1 -right-1 bg-black rounded-full border border-electric-lime/30 p-1 shadow-lg">
                  <SoundWave />
                </div>
              )}
            </div>
            <div>
              <h2 className="font-extrabold tracking-tight text-lg uppercase">BRO-BOT AI</h2>
              <span className="text-[10px] text-electric-lime uppercase font-black tracking-widest">Senior Wingman</span>
            </div>
          </div>
          <button 
            onClick={() => setIsMuted(!isMuted)}
            className={`p-2 rounded-xl transition-all ${isMuted ? 'text-slate-500 bg-white/5' : 'text-electric-lime bg-electric-lime/10'}`}
          >
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </div>

        <div id="chat-messages" className="flex-1 overflow-y-auto p-8 space-y-8">
          <AnimatePresence initial={false}>
            {messages.map((m, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: m.role === 'bro' ? -20 : 20, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                className={`flex gap-3 ${m.role === 'bro' ? 'flex-row' : 'flex-row-reverse'}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-lg ${
                  m.role === 'bro' ? 'bg-slate-800 text-electric-lime border border-white/5' : 'bg-electric-lime text-black'
                }`}>
                  {m.role === 'bro' ? <Bot size={16} /> : <User size={16} />}
                </div>
                <div className={`max-w-[85%] p-4 rounded-2xl text-[13px] leading-relaxed shadow-sm relative group ${
                  m.role === 'bro' 
                    ? 'bg-slate-900/80 border border-white/5 text-slate-200 rounded-tl-none' 
                    : 'bg-electric-lime text-black font-bold rounded-tr-none'
                }`}>
                  {m.content}
                  {m.role === 'bro' && (
                    <button 
                      onClick={() => handleSpeak(m.content)}
                      disabled={isSpeaking}
                      className="absolute -right-10 top-2 opacity-0 group-hover:opacity-100 transition-opacity p-2 text-slate-500 hover:text-electric-lime disabled:opacity-30"
                    >
                      <Volume2 size={16} />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
            {isLoading && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ duration: 0.3 }}
                className="flex gap-3"
              >
                <div className="w-8 h-8 rounded-full bg-slate-800 text-electric-lime border border-white/5 flex items-center justify-center shrink-0">
                  <Bot size={16} />
                </div>
                <div className="p-4 bg-slate-900/80 border border-white/5 rounded-2xl rounded-tl-none flex items-center gap-1.5 shadow-sm">
                  <motion.div 
                    animate={{ opacity: [0.3, 1, 0.3] }} 
                    transition={{ repeat: Infinity, duration: 1, delay: 0 }}
                    className="w-1.5 h-1.5 bg-electric-lime rounded-full" 
                  />
                  <motion.div 
                    animate={{ opacity: [0.3, 1, 0.3] }} 
                    transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                    className="w-1.5 h-1.5 bg-electric-lime rounded-full" 
                  />
                  <motion.div 
                    animate={{ opacity: [0.3, 1, 0.3] }} 
                    transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                    className="w-1.5 h-1.5 bg-electric-lime rounded-full" 
                  />
                  <span className="ml-2 text-[10px] text-slate-500 uppercase font-black tracking-widest italic">Bro is thinking...</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <form onSubmit={handleSend} className="p-8 border-t border-white/5 bg-slate-950/80">
          <div className="relative flex items-center gap-2">
            <div className="relative flex-1">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask anything, Maca..."
                className="w-full bg-slate-900 border border-white/10 rounded-2xl px-6 py-4 pr-14 outline-none focus:border-electric-lime/40 transition-all text-sm"
              />
              <button 
                type="button"
                onClick={startListening}
                className={`absolute right-2 top-2 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse' 
                    : 'bg-white/5 text-slate-400 hover:text-electric-lime hover:bg-white/10'
                }`}
              >
                {isListening ? <MicOff size={18} /> : <Mic size={18} />}
              </button>
            </div>
            <button className="w-12 h-12 bg-electric-lime text-black rounded-xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all shrink-0">
              <Send size={20} />
            </button>
          </div>
        </form>
      </aside>

      {/* Main Recipe Display */}
      <main className="flex-1 overflow-y-auto p-16 relative">
        <AnimatePresence>
          {voiceError && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed bottom-12 right-12 z-50 max-w-sm"
            >
              <div className="bg-slate-900 border border-red-500/30 p-5 rounded-[24px] shadow-2xl backdrop-blur-xl flex flex-col gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                    <AlertCircle className="text-red-500 w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-black text-xs uppercase tracking-widest mb-1">VOICE SCENE FAILED</h4>
                    <p className="text-slate-400 text-[11px] leading-relaxed italic">Bro, the audio relay is lagging. Mic is acting up. Want to retry?</p>
                  </div>
                  <button onClick={() => setVoiceError(null)} className="text-slate-500 hover:text-white transition-colors">
                    <X size={16} />
                  </button>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleSpeak(voiceError.text)}
                    className="flex-1 bg-white text-black py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-electric-lime transition-all flex items-center justify-center gap-2"
                  >
                    <RefreshCcw size={12} /> Retry Audio
                  </button>
                  <button 
                    onClick={() => setVoiceError(null)}
                    className="px-4 border border-white/10 text-slate-300 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/5 transition-all"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {!currentRecipe ? (
          <div className="h-full flex items-center justify-center text-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="w-24 h-24 glass rounded-[32px] flex items-center justify-center mx-auto mb-8 shadow-xl">
                <User className="text-white/10 w-10 h-10" />
              </div>
              <h1 className="text-4xl font-black mb-4 uppercase tracking-tighter text-white/20">NO RECIPE SCENE YET</h1>
              <p className="text-slate-400 max-w-xs mx-auto text-sm leading-relaxed">Talk to Bro-Bot on the left to generate your first killer student meal.</p>
            </motion.div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            <AnimatePresence mode="wait">
              {(isGeneratingImage || recipeImageUrl) && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="mb-12 rounded-[40px] overflow-hidden shadow-2xl border border-white/5 aspect-[21/9] relative bg-slate-900"
                >
                  {isGeneratingImage ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-slate-900">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="w-10 h-10 border-2 border-electric-lime border-t-transparent rounded-full"
                      />
                      <span className="text-[10px] text-electric-lime font-black uppercase tracking-[2px]">Generating Aesthetic Scene...</span>
                    </div>
                  ) : (
                    <img 
                      src={recipeImageUrl || ""} 
                      alt={currentRecipe.recipeName} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60" />
                  <div className="absolute bottom-6 left-8 flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-electric-lime">
                        <ImageIcon size={14} />
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-widest text-white/50 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full">AI Generated Vision</span>
                    </div>

                    {!videoUrl ? (
                      <button 
                        onClick={handleStartVideo}
                        disabled={isVideoLoading}
                        className="flex items-center gap-2 bg-white text-black px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest hover:bg-electric-lime transition-all disabled:opacity-50 group"
                      >
                        {isVideoLoading ? (
                          <RefreshCcw size={10} className="animate-spin" />
                        ) : (
                          <Video size={10} className="group-hover:scale-110 transition-transform" />
                        )}
                        {isVideoLoading ? 'Directing Scene...' : 'Gen Cooking Video'}
                      </button>
                    ) : (
                      <div className="flex items-center gap-2">
                         <div className="w-8 h-8 rounded-full bg-electric-lime text-black flex items-center justify-center animate-pulse cursor-pointer shadow-[0_0_15px_rgba(180,255,0,0.5)]">
                           <Play size={14} fill="currentColor" />
                         </div>
                         <span className="text-[8px] font-black uppercase tracking-widest text-electric-lime bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-electric-lime/30">Video Ready Bro!</span>
                      </div>
                    )}
                  </div>

                  {videoUrl && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="absolute inset-0 z-20 bg-black group"
                    >
                      <video 
                        src={videoUrl} 
                        controls 
                        autoPlay
                        className="w-full h-full object-cover"
                      />
                      <button 
                        onClick={() => setVideoUrl(null)}
                        className="absolute top-4 right-4 bg-black/40 backdrop-blur-md text-white p-2 rounded-full hover:bg-white/10 transition-all opacity-0 group-hover:opacity-100"
                      >
                        <X size={16} />
                      </button>
                    </motion.div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-16"
            >
              <div className="flex flex-wrap gap-4 mb-8">
                <span className="px-5 py-2 glass-pill rounded-full text-[10px] font-black uppercase flex items-center gap-2 tracking-widest">
                  <Clock className="w-4 h-4 text-electric-lime" /> 15 Mins
                </span>
                <span className="px-5 py-2 bg-electric-lime/10 border border-electric-lime/20 text-electric-lime rounded-full text-[10px] font-black uppercase flex items-center gap-2 tracking-widest">
                  <DollarSign className="w-4 h-4" /> Estimate: {currentRecipe.estimateCost}
                </span>
              </div>
              <h1 className="text-7xl font-extrabold tracking-[-3px] mb-10 uppercase leading-[0.9]">{currentRecipe.recipeName}</h1>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                <div className="space-y-12">
                  <div>
                    <h3 className="text-electric-lime font-black uppercase tracking-[2px] text-[10px] mb-8">The Requirements</h3>
                    <ul className="space-y-4">
                      {currentRecipe.ingredients.map((ing, i) => (
                        <motion.li 
                          key={i} 
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: i * 0.05, duration: 0.4 }}
                          className="flex items-center gap-5 group cursor-pointer"
                          onClick={() => toggleIngredient(i)}
                        >
                          <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${
                            checkedIngredients.has(i) 
                              ? 'bg-electric-lime border-electric-lime text-black scale-110 shadow-[0_0_15px_rgba(180,255,0,0.3)]' 
                              : 'border-slate-800 bg-slate-900 group-hover:border-slate-700'
                          }`}>
                            <AnimatePresence>
                              {checkedIngredients.has(i) && (
                                <motion.div
                                  initial={{ scale: 0, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  exit={{ scale: 0, opacity: 0 }}
                                >
                                  <Check size={14} strokeWidth={4} />
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                          <span className={`text-lg transition-all ${
                            checkedIngredients.has(i) 
                              ? 'text-slate-500 line-through' 
                              : 'text-slate-400 group-hover:text-white'
                          }`}>{ing}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </div>

                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                    className="space-y-6"
                  >
                    <h3 className="text-electric-lime font-black uppercase tracking-[2px] text-[10px] mb-4">Execution Plan</h3>
                    <div className="grid gap-3">
                      {currentRecipe.steps.map((step, i) => (
                        <motion.div 
                          key={i} 
                          initial={{ opacity: 0, y: 10 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.05 }}
                          className="p-4 bg-slate-900/40 border border-white/5 rounded-2xl text-xs leading-relaxed text-slate-300"
                        >
                          <span className="text-electric-lime font-bold mr-2">{i + 1}.</span> {step}
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                </div>

                <div className="sticky top-8 space-y-8">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="relative group h-[400px]"
                  >
                    {/* Glassmorphism GIF Container */}
                    <motion.div
                      animate={{ 
                        boxShadow: [
                          "0 0 20px rgba(204, 255, 0, 0.1)", 
                          "0 0 40px rgba(204, 255, 0, 0.3)", 
                          "0 0 20px rgba(204, 255, 0, 0.1)"
                        ] 
                      }}
                      transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                      className="absolute inset-0 bg-slate-900/50 backdrop-blur-xl border-2 border-electric-lime/30 rounded-[40px] overflow-hidden"
                    >
                      {isFetchingGif ? (
                        <div className="h-full flex flex-col items-center justify-center gap-4">
                          <RefreshCcw size={32} className="text-electric-lime animate-spin opacity-50" />
                          <span className="text-[10px] text-electric-lime font-black uppercase tracking-widest italic opacity-50">Fetching Vibes...</span>
                        </div>
                      ) : recipeGifUrl ? (
                        <div className="h-full relative">
                          <img 
                            src={recipeGifUrl} 
                            alt="Cooking Vibe" 
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                          <div className="absolute bottom-8 left-8 right-8">
                            <motion.div
                              animate={{ scale: [1, 1.05, 1] }}
                              transition={{ repeat: Infinity, duration: 2 }}
                              className="bg-electric-lime text-black px-4 py-2 rounded-full inline-block text-[10px] font-black uppercase tracking-widest shadow-[0_0_20px_rgba(180,255,0,0.5)]"
                            >
                              {Math.random() > 0.5 ? 'This is the goal, Bro!' : 'Watch & Learn, Da!'}
                            </motion.div>
                          </div>
                        </div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-700">
                          <ImageIcon size={48} />
                          <span className="mt-4 text-[10px] font-black uppercase tracking-widest italic">No GIF Scene Found</span>
                        </div>
                      )}
                    </motion.div>

                    {/* Decorative Neon Ring */}
                    <div className="absolute -inset-1 border border-electric-lime/10 rounded-[44px] -z-10" />
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: 0.2 }}
                    className="glass p-8 rounded-[32px] border-l-4 border-l-electric-lime relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-electric-lime/5 blur-3xl rounded-full" />
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-white font-black uppercase tracking-[2px] text-[10px]">Bro-Tip</h3>
                      <button 
                        onClick={() => handleSpeak(currentRecipe.broTip)}
                        disabled={isSpeaking}
                        className={`p-2 glass-pill rounded-full transition-all flex items-center gap-2 px-3 ${
                          isSpeaking 
                            ? 'text-electric-lime border-electric-lime/30 bg-electric-lime/5' 
                            : 'text-white/50 hover:text-electric-lime hover:bg-white/10'
                        } disabled:opacity-50`}
                      >
                        <Volume2 size={16} className={isSpeaking ? 'animate-pulse' : ''} />
                        {isSpeaking && <span className="text-[8px] font-black uppercase tracking-widest">Speaking</span>}
                      </button>
                    </div>
                    <p className="italic text-xl leading-relaxed text-slate-200">
                      "{currentRecipe.broTip}"
                    </p>
                  </motion.div>
                </div>
              </div>
            </motion.div>

            {/* Execution Plan removed from here as it's moved to left-column or better layout */}
            
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mt-32"
            >
              <div className="flex items-center gap-4 mb-12">
                <h2 className="text-3xl font-black uppercase tracking-tighter">You might also like, Bro</h2>
                <div className="h-px flex-1 bg-white/5" />
              </div>

              {isFetchingRelated ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="h-48 glass rounded-[32px] animate-pulse bg-white/5" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {relatedRecipes.map((recipe, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ y: -10 }}
                      className="group p-8 glass rounded-[32px] border border-white/5 hover:border-electric-lime/30 transition-all cursor-pointer relative overflow-hidden"
                      onClick={() => handleBroAdvice(recipe.name)}
                    >
                      <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ChevronRight className="text-electric-lime" size={20} />
                      </div>
                      <div className="flex flex-col h-full justify-between gap-8">
                        <h4 className="text-xl font-bold leading-tight group-hover:text-electric-lime transition-colors">
                          {recipe.name}
                        </h4>
                        <div className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest text-slate-500">
                          <span className="flex items-center gap-1.5"><Clock size={12} className="text-electric-lime" /> {recipe.time}</span>
                          <span className="flex items-center gap-1.5"><DollarSign size={12} className="text-electric-lime" /> {recipe.cost}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>

            <div className="h-px bg-white/5 w-full my-20" />
            
            <div className="text-center mb-20">
              <h3 className="text-white/20 font-black uppercase tracking-[10px] text-[12px] mb-4 italic">End of Instruction Scene</h3>
              <p className="text-slate-600 text-xs tracking-widest uppercase">Safe Journey with your hunger, Da!</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
