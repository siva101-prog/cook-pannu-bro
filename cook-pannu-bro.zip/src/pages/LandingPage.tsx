import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { ChefHat, ShoppingCart, TrendingDown, ArrowRight, Smartphone } from "lucide-react";
import { useState, FormEvent, ReactNode } from "react";

export default function LandingPage() {
  const [fridgeInput, setFridgeInput] = useState("");
  const navigate = useNavigate();

  const handleQuickCook = (e: FormEvent) => {
    e.preventDefault();
    if (fridgeInput) {
      navigate(`/cook?ingredients=${encodeURIComponent(fridgeInput)}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white selection:bg-electric-lime selection:text-black">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 px-10 py-6 flex items-center justify-between border-b border-white/5 backdrop-blur-md bg-slate-950/50">
        <div className="flex items-center gap-2">
          <div className="text-2xl font-extrabold tracking-tighter">
            COOK <span className="text-electric-lime">PANNU</span> BRO
          </div>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
          <Link to="/" className="text-electric-lime transition-colors">Home</Link>
          <Link to="/dashboard" className="hover:text-electric-lime transition-colors">Market Watch</Link>
          <Link to="/cook" className="hover:text-electric-lime transition-colors">Bro's Kitchen</Link>
          <Link to="/dashboard" className="hover:text-electric-lime transition-colors">Pantry</Link>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden lg:block bg-slate-800 px-4 py-2 border border-electric-lime/15 rounded-full text-xs font-semibold">
            ₹2,450 Saved This Month
          </div>
          <Link 
            to="/auth" 
            className="px-6 py-2.5 rounded-full bg-slate-800 border border-electric-lime/15 text-white hover:bg-electric-lime hover:text-black transition-all font-bold text-xs uppercase tracking-wider"
          >
            Bro, Login
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto pt-44 pb-20 px-10 grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
        <div className="hero-content">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-7xl md:text-[72px] font-extrabold mb-6 leading-[0.95] tracking-[-3px]">
              Stop ordering<br />
              out, <span className="text-electric-lime">Maca.</span>
            </h1>
            <p className="text-lg text-slate-400 mb-10 max-w-lg leading-relaxed">
              The ultimate cooking wingman for students. Track local mandi prices, 
              manage your mess pantry, and get recipes that won't break your bank. 
              Scene heavy, da.
            </p>

            <div className="glass p-8 rounded-[20px] shadow-[0_0_30px_rgba(204,255,0,0.05)]">
              <span className="text-xs uppercase tracking-[1px] font-bold text-electric-lime block mb-3">Quick Recipe Search</span>
              <form onSubmit={handleQuickCook} className="relative mb-4">
                <input
                  type="text"
                  placeholder="Eg: 2 Eggs, Bread, Half Onion..."
                  value={fridgeInput}
                  onChange={(e) => setFridgeInput(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 pr-32 text-white outline-none focus:border-electric-lime/30 transition-all"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-2 bottom-2 bg-electric-lime text-black px-6 rounded-lg font-bold text-sm transition-transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  Get Advice
                </button>
              </form>
              <p className="text-sm italic text-slate-400 flex items-center gap-2">
                "Bro, you can make a mean Masala Toast with this. Don't be a dummy!"
              </p>
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="widget-stack flex flex-col gap-6"
        >
          {/* Market Intel Widget */}
          <div className="glass p-6 rounded-[24px]">
             <span className="bg-electric-lime/10 text-electric-lime text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider mb-2 inline-block">Live Price Intel</span>
             <h3 className="text-base font-bold mb-4">Current Mandi vs Zepto</h3>
             <div className="grid grid-cols-3 gap-3">
                <PriceWidget item="Onion (1kg)" price="₹32" change="-12%" up={false} />
                <PriceWidget item="Tomato (1kg)" price="₹45" change="+4%" up={true} />
                <PriceWidget item="Milk (500ml)" price="₹28" change="-2%" up={false} />
             </div>
          </div>

          {/* Savings Widget */}
          <div className="glass p-6 rounded-[24px]">
             <span className="bg-electric-lime/10 text-electric-lime text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider mb-2 inline-block">Savings Scene</span>
             <h3 className="text-base font-bold mb-4">Money Saved vs Eating Out</h3>
             <div className="flex items-end gap-2 h-20 px-2">
                {[40, 60, 30, 80, 50, 90, 70].map((h, i) => (
                  <div key={i} className="flex-1 bg-slate-800 rounded-sm relative h-full">
                    <div className="absolute bottom-0 w-full bg-electric-lime/80 rounded-sm" style={{ height: `${h}%` }} />
                  </div>
                ))}
             </div>
             <div className="flex justify-between mt-3 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
               <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span className="text-electric-lime">Fri</span>
             </div>
          </div>

          <div className="glass p-5 rounded-[24px] border-l-4 border-l-electric-lime">
             <h3 className="text-sm font-bold text-electric-lime uppercase tracking-wider">Bro-Tip of the day</h3>
             <p className="text-xs text-slate-400 mt-2 leading-relaxed italic">
               "Maca, don't buy the precut veggies from the app. Hit the local market behind the hostel on Thursdays. Save that for the weekend trip!"
             </p>
          </div>
        </motion.div>
      </main>
      <footer className="py-10 border-t border-white/5 text-center text-slate-600 text-[10px] uppercase font-bold tracking-widest bg-slate-950">
        <p>© 2026 Cook Pannu Bro. All rights reserved. Made for the Macas.</p>
      </footer>
    </div>
  );
}

function PriceWidget({ item, price, change, up }: { item: string, price: string, change: string, up: boolean }) {
  return (
    <div className="bg-black/20 p-3 rounded-xl border border-white/5">
      <div className="text-[10px] text-slate-400 uppercase font-black tracking-tight">{item}</div>
      <div className="text-lg font-bold mt-1 flex items-baseline gap-1">
        {price}
        <span className={`text-[10px] ${up ? 'text-red-500' : 'text-green-400'}`}>{change}</span>
      </div>
    </div>
  );
}


function FeatureCard({ icon, title, description }: { icon: ReactNode, title: string, description: string }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="p-8 bg-white/5 border border-white/10 rounded-3xl group hover:border-[#CCFF00]/50 transition-all duration-300 relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-[#CCFF00]/5 blur-3xl rounded-full group-hover:bg-[#CCFF00]/10 transition-all" />
      <div className="mb-6 w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center border border-white/10 group-hover:border-[#CCFF00]/30 transition-all">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-white/50 leading-relaxed">{description}</p>
    </motion.div>
  );
}
